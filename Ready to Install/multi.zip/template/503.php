<div class="container-fluid">
	<div class="card text-center">
		<h1 class="mb-0"><?php echo $text['503'];?></h1>
		<h5 class="mb-0"><?php echo $text['503_title'];?></h5>
		<p><?php echo $text['503_description'];?></p>
	</div>
</div>
