<?php
$DataBase = array(
	'hostname' => 'localhost',
	'username' => 'mahtab2003',
	'password' => '',
	'name' => 'hosting',
);
?>