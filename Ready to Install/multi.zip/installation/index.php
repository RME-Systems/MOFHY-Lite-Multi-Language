<?php
$PageInfo = ['title'=>'Installation'];
require_once __DIR__.'/includes/Header.php';
include __DIR__.'/template/Home.php';
require_once __DIR__.'/includes/Footer.php';
?>